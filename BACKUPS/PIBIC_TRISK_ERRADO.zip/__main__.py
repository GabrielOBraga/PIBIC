# coding=utf-8
import time

import numpy as np
import os

from sklearn.externals.joblib._multiprocessing_helpers import mp

from Forest_GA.PIBIC.ga import Individuo, GeneticAlgorithm, Consultas, Impressao
from Forest_GA.PIBIC.h_l2rMiscellaneous import load_L2R_file
from Forest_GA.forest import Forest


def main():
    comparar = 0
    executar_por_fold = 1

    rota_pasta_letor = "../Colecoes/2003_td_dataset/"
    numero_de_estimadores = 1000

    ################################################ Aplicar MultThread GA #######################################

    if executar_por_fold:

        ex_vetor_n_arvores = [1000]  ##[1000,2000,3000]
        ex_geracoes = [30]  ##[1]           1  e 1 para gerar os resultados de RF
        ex_n_individuos = [75]  ##[1]      75

        ##folds_works(ga, rota_pasta_letor, n_individuos, n_geracoes, n_arvores)
        ##for nn in ex_vetor_n_arvores:
        for gg in ex_geracoes:
            for ii in ex_n_individuos:
                processes = [mp.Process(target=folds_works, args=([1, 1, 1], rota_pasta_letor, ii, gg, nn, "tRisk")) for
                             nn in ex_vetor_n_arvores]

                # Run processes
                for p in processes:
                    p.start()

                # Exit the completed processes
                for p in processes:
                    p.join()

    ################################################ Testar o GA ################################################

    if comparar:
        numero_de_estimadores = 1000
        RandomForest = Forest(random_state=0, n_estimators=numero_de_estimadores, n_jobs=4)


        """
            Forest(bootstrap=True, criterion='mse', max_depth=2,
                   max_features='auto', max_leaf_nodes=None,
                   min_impurity_decrease=0.0, min_impurity_split=None,
                   min_samples_leaf=1, min_samples_split=2,
                   min_weight_fraction_leaf=0.0, n_estimators=1000, n_jobs=1,
                   oob_score=False, random_state=0, verbose=0, warm_start=False)
        """

        fold = "4"

        nomeArquivoTrain = rota_pasta_letor + "Fold" + fold + "/Norm.train.txt"
        nomeArquivoVali = rota_pasta_letor + "Fold" + fold + "/Norm.vali.txt"
        nomeArquivoTest = rota_pasta_letor + "Fold" + fold + "/Norm.test.txt"

        MASK = [1] * 64


        print("Lendo Arquivos ...")
        X, y, z = load_L2R_file(nomeArquivoTrain, MASK)
        X2, y2, z2 = load_L2R_file(nomeArquivoVali, MASK)
        X3, y3, z3 = load_L2R_file(nomeArquivoTest, MASK)

        Vetores_train = Consultas(X, y, z)
        Vetores_Vali = Consultas(X2, y2, z2)
        Vetores_Test = Consultas(X3, y3, z3)

        '''##############################################################################################################'''
        '''##############################################################################################################'''

        print("Arquivos Lidos:")
        print(nomeArquivoTrain)
        print(nomeArquivoVali)
        print(nomeArquivoTest)

        forest = np.ones(1000)
        '''forest = [1,1,0,0,0,0,0,1,1,1,1,1,0,1,1,1,0,1,1,1,0,1,0,1,0,0,1,1,1,1,0,1,0,1,1,0,0,1,0,1,0,0,1,0,0,1,1,1,
        1,1,1,0,1,1,0,1,1,1,0,0,0,1,1,1,0,0,0,1,0,0,0,0,0,1,0,1,1,1,0,1,0,1,1,0,1,0,0,0,0,1,1,1,0,0,0,1,0,0,1,1,1,1,
        0,1,1,0] '''
        GA = GeneticAlgorithm([], 1)
        GA.num_caracteristicas = numero_de_estimadores
        GA.tamanho_populacao = 1

        ind = Individuo(forest, 1)
        RandomForest.Fold = 1

        start = time.clock()

        GA.populacao = RandomForest.fit_forest([ind], Vetores_train, Vetores_Vali)
        GA.num_geracao = 1

        final = time.clock() - start

        imprimir_individuo(ind, numero_de_estimadores, 1, 1, fold, [0, 0, 0], final)


def folds_works(ga, rota_pasta_letor, n_individuos, n_geracoes, n_arvores, mode="ndcg"):
    MASK = [1] * 64

    forest = Forest(n_estimators=n_arvores, n_jobs=4)

    selecaoTorneio = ga[0]
    crossoverUniforme = ga[1]
    elitist = ga[2]

    for fold in range(1, 6):
        name_train = rota_pasta_letor + "Fold" + str(fold) + "/" + "Norm.train.txt"
        name_vali = rota_pasta_letor + "Fold" + str(fold) + "/" + "Norm.vali.txt"
        name_test = rota_pasta_letor + "Fold" + str(fold) + "/" + "Norm.test.txt"

        X, y, z = load_L2R_file(name_train, MASK)
        X2, y2, z2 = load_L2R_file(name_vali, MASK)
        X3, y3, z3 = load_L2R_file(name_test, MASK)

        Vetores_train = Consultas(X, y, z)
        Vetores_Vali = Consultas(X2, y2, z2)
        Vetores_Test = Consultas(X3, y3, z3)

        forest.Fold = fold
        forest.n_estimators = n_arvores
        forest.size = n_arvores

        if (n_individuos == 1) or (n_geracoes == 1):
            geracao = [1] * n_arvores
            Ind = Individuo(geracao, 1)
            individuo = forest.fit_forest([Ind], Vetores_train, Vetores_Test, mode="ndcg")
            imprimir_individuo(individuo[0], n_arvores, n_geracoes, n_individuos, fold, ga)
        else:
            individuo = forest.ga([Vetores_train, Vetores_Vali, Vetores_Test], n_individuos, n_geracoes, selecaoTorneio,
                                  crossoverUniforme, elitist, n_arvores, mode)
            imprimir_individuo(individuo, n_arvores, n_geracoes, n_individuos, fold, ga)


def imprimir_individuo(individuo, num_arvores, num_geracao, total_geracao, fold, ga, time=0):
    '''
    Final Por Fold			Pasta			Nome Arquivo
			                FinalResultados/			/TheBests
    coleção		Fitness		GA
    fold	n arvores	ndcg	map	    geração	g. Ind	qt. ind	selecao	crossover	mutacao	elitismo	mascara

    1	    1000	    0.358	0.24	50  	48	    30	    1	    1   	1	    1
    '''

    try:
        os.mkdir('FinalResultados')
    except OSError:
        print('.')

    map = individuo.map

    if time != 0:
        arquivo_name = 'FinalResultados/Compare_' + str(num_arvores) + '.csv'
        map = time
    elif num_geracao == 1:
        arquivo_name = 'FinalResultados/Original_' + str(num_arvores) + '.csv'
    else:
        arquivo_name = 'FinalResultados/TheBests_' + str(num_arvores) + '.csv'
    arquivo = open(arquivo_name, 'a+')

    arquivo.write('{0};{1};{2};{3};{4};{5};{6};{7};{8};{9};'.format(str(fold), str(num_arvores), str(individuo.fitness),
                                                                    str(map), str(num_geracao), str(total_geracao),
                                                                    str(individuo.geracao), str(ga[0]), str(ga[1]),
                                                                    str(ga[2])))
    for i in individuo.mascara:
        arquivo.write(str(int(i)))
    arquivo.write("\n")

    arquivo.close()


'''
    Vetor_n_Arvores

       n_forest = numero de individuos no GA
       max_num_geracoes = numero de Gerações
        
    Vetor de elitist, crossover, selecao
        elitismo
            1 = true
            0 = false

        crossover
            1 = ponto a ponto
            0 = uniforme

        seleção
            1 = roleta
            0 = torneio
    '''

if __name__ == '__main__':
    main()
