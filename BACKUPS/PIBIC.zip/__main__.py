# coding=utf-8
import time

import numpy as np
from sklearn.externals.joblib._multiprocessing_helpers import mp

from Forest_GA.PIBIC.ga import Individuo, GeneticAlgorithm, Consultas, Impressao
from Forest_GA.PIBIC.h_l2rMiscellaneous import load_L2R_file
from Forest_GA.forest import Forest


def chamada(regr, vetor_n_arvores, vetor):
    elitist = vetor[0]
    crossoverPonto = vetor[1]
    selecaoRoleta = vetor[2]

    n_forest = vetor_n_arvores[0]
    max_num_geracoes = vetor_n_arvores[1]

    temp = regr.ga(n_forest, max_num_geracoes, elitist, crossoverPonto, selecaoRoleta)
    print(temp)


'''
   Vetor_n_Arvores

       n_forest = numero de individuos no GA
       max_num_geracoes = numero de Gerações
'''
vetor_n_arvores = [
    [20, 20],
    # [40, 50],
    [50, 20],
    # [60, 50],
    # [70, 30],
    # [100, 50],
    ##[150, 20],
    ##[200, 20],
    ##[300, 20]
]

''' Vetor de elitist, crossover, selecao
        elitismo
            1 = true
            0 = false

        crossover
            1 = ponto a ponto
            0 = uniforme

        seleção
            1 = roleta
            0 = torneio
    '''
vetor_ga = [  # [0, 0, 1],
    [0, 1, 0],
    [0, 1, 1],
    # [1, 0, 0],
    [1, 0, 1],
    [1, 1, 0],
    # [1, 1, 1],
    # [0, 0, 0]
]


def imprimir_individuo(individuo, num_arvores, num_geracao,total_geracao, fold, ga):

    '''
    Final Por Fold			Pasta			Nome Arquivo
			                FinalResultados/			/TheBests
    coleção		Fitness		GA
    fold	n arvores	ndcg	map	    geração	g. Ind	qt. ind	selecao	crossover	mutacao	elitismo	mascara

    1	    1000	    0.358	0.24	50  	48	    30	    1	    1   	1	    1
    '''

    if num_geracao == 1:
        arquivo_name = 'FinalResultados/Original_' + str(num_arvores) + '.csv'
    else:
        arquivo_name = 'FinalResultados/TheBests_' + str(num_arvores) + '.csv'

    arquivo = open(arquivo_name, 'a+')



    arquivo.write('{0};{1};{2};{3};{4};{5};{6};{7};{8};{9};'.format(str(fold), str(num_arvores), str(individuo.fitness),
                                                                   str(individuo.map), str(num_geracao), str(total_geracao),
                                                                   str(individuo.geracao), str(ga[0]), str(ga[1]),
                                                                   str(ga[2])))
    for i in individuo.mascara:
        arquivo.write(str(int(i)))
    arquivo.write("\n")

    arquivo.close()


def folds_works(ga, rota_pasta_letor, n_individuos, n_geracoes, n_arvores):
    MASK = [1] * 64

    forest = Forest(n_estimators=n_arvores, n_jobs=-1)

    selecaoTorneio = ga[0]
    crossoverUniforme = ga[1]
    elitist = ga[2]

    for fold in range(1, 6):
        name_train = rota_pasta_letor + "Fold" + str(fold) + "/" + "Norm.train.txt"
        name_vali = rota_pasta_letor + "Fold" + str(fold) + "/" + "Norm.vali.txt"
        name_test = rota_pasta_letor + "Fold" + str(fold) + "/" + "Norm.test.txt"

        X, y, z = load_L2R_file(name_train, MASK)
        X2, y2, z2 = load_L2R_file(name_vali, MASK)
        X3, y3, z3 = load_L2R_file(name_test, MASK)

        Vetores_train = Consultas(X, y, z)
        Vetores_Vali = Consultas(X2, y2, z2)
        Vetores_Test = Consultas(X3, y3, z3)

        forest.Fold = fold
        forest.n_estimators = n_arvores
        forest.size = n_arvores

        if (n_individuos ==1) or (n_geracoes == 1):
            geracao = [1] * n_arvores
            Ind = Individuo(geracao, 1)
            individuo = forest.fit_forest([Ind], Vetores_train, Vetores_Test)
            imprimir_individuo(individuo[0], n_arvores, n_geracoes,n_individuos, fold,ga)
        else:
            individuo = forest.ga([Vetores_train, Vetores_Vali, Vetores_Test], n_individuos, n_geracoes, selecaoTorneio, crossoverUniforme, elitist, n_arvores)
            imprimir_individuo(individuo, n_arvores, n_geracoes,n_individuos, fold, ga)


def main():
    fit = 0
    aplicar_ga = 0
    executar = 0
    comparar = 0
    executar_por_fold = 1

    rota_pasta_letor = "../Colecoes/2003_td_dataset/"
    numero_de_estimadores = 1000

    if 0:
        RandomForest = Forest(max_depth=2, random_state=0, n_estimators=numero_de_estimadores)

        """
            Forest(bootstrap=True, criterion='mse', max_depth=2,
                   max_features='auto', max_leaf_nodes=None,
                   min_impurity_decrease=0.0, min_impurity_split=None,
                   min_samples_leaf=1, min_samples_split=2,
                   min_weight_fraction_leaf=0.0, n_estimators=1000, n_jobs=1,
                   oob_score=False, random_state=0, verbose=0, warm_start=False)
        """

        ''' Gerar inicialmente as 1000 arvores de decisoes'''

    if 0:
        nomeArquivoTrain = "Forest_GA/2003_td_dataset/Fold1/Norm.train.txt"
        nomeArquivoVali = "Forest_GA/2003_td_dataset/Fold1/Norm.vali.txt"
        nomeArquivoTest = "Forest_GA/2003_td_dataset/Fold1/Norm.test.txt"

        MASK = [1] * 64

        print("Lendo Arquivos ...")
        X, y, z = load_L2R_file(nomeArquivoTrain, MASK)
        X2, y2, z2 = load_L2R_file(nomeArquivoVali, MASK)
        X3, y3, z3 = load_L2R_file(nomeArquivoTest, MASK)

        Vetores_train = Consultas(X, y, z)
        Vetores_Vali = Consultas(X2, y2, z2)
        Vetores_Test = Consultas(X3, y3, z3)

        '''##############################################################################################################'''
        '''##############################################################################################################'''

        print("Arquivos Lidos:")
        print(nomeArquivoTrain)
        print(nomeArquivoVali)
        print(nomeArquivoTest)

    ################################################ Aplicar 1 GA ################################################

    if aplicar_ga:
        print("Função Forest.ga() chamada")

        # #temp = regr.ga(VetoresXYZ, n_forest=70, max_num_geracoes=10, selecaoTorneio=1,
        # crossoverUniforme=1,elitist=1, numero_genes=1000)

        folds_works([1, 1, 1], rota_pasta_letor, 1, 1, 1000)
        folds_works([1, 1, 1], rota_pasta_letor, 1, 1, 2000)
        ##temp = RandomForest.ga([Vetores_train, Vetores_Vali, Vetores_Test], 10, 2, 1, 1, 1, 1000)

    ################################################ Aplicar MultThread GA #######################################

    if executar:
        forests = [RandomForest] * 10

        # Setup a list of processes that we want to run
        for x in range(len(vetor_n_arvores)):
            processes = [mp.Process(target=chamada, args=(forests[i], vetor_n_arvores[x], vetor_ga[i])) for i in
                         (range(len(vetor_ga)))]

            # Run processes
            for p in processes:
                p.start()

            # Exit the completed processes
            for p in processes:
                p.join()

    if executar_por_fold:

        ex_vetor_n_arvores = [1000,2000] ##[1000,2000,3000]
        ex_geracoes = [30] ##[30, 70, 100]           1  e 1 para gerar os resultados de RF
        ex_n_individuos = [75] ##[32, 52, 102]      75

        ##folds_works(ga, rota_pasta_letor, n_individuos, n_geracoes, n_arvores)
        ##for nn in ex_vetor_n_arvores:
        for gg in ex_geracoes:
            for ii in ex_n_individuos:
                processes = [mp.Process(target=folds_works, args=([1, 1, 1], rota_pasta_letor, ii, gg, nn)) for nn in ex_vetor_n_arvores]

                # Run processes
                for p in processes:
                    p.start()

                # Exit the completed processes
                for p in processes:
                    p.join()

    ################################################ Testar o GA ################################################

    if comparar:
        forest = np.ones(1000)
        '''
                forest = [0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0,
                          1, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1,
                          1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1,
                          1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0,
                          1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1,
                          1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0,
                          0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1,
                          1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0,
                          1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1,
                          0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1,
                          1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1,
                          0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0,
                          1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1,
                          1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0,
                          1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1,
                          1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1,
                          1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0,
                          0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0,
                          1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1,
                          0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0,
                          0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1,
                          0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0,
                          0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0,
                          0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0,
                          0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1,
                          1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0,
                          1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 1,
                          0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 0,
                          1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1,
                          1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1,
                          0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0,
                          1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1,
                          1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1,
                          0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0,
                          1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1,
                          1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1,
                          0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0,
                          0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1,
                          1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0,
                          1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0,
                          0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0,
                          1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, ]
        '''

        GA = GeneticAlgorithm([], 1)
        GA.num_caracteristicas = numero_de_estimadores
        GA.tamanho_populacao = 1

        ind = Individuo(forest, 1)
        RandomForest.Fold = 1

        start = time.clock()

        GA.populacao = RandomForest.fit_forest([ind], Vetores_train, Vetores_Vali)
        GA.num_geracao = 1

        final = time.clock() - start

        Impressao([ind], [0, 0, 0], final)


if __name__ == '__main__':
    main()
