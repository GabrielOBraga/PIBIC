#!-*- conding: utf8 -*-
import statistics
import threading
import time

import numpy as np

from Forest_GA.PIBIC.h_l2rMeasures import getQueries, average_precision, ndcg, modelEvaluation
from Forest_GA.PIBIC.rank_metrics import ndcg_at_k
from Forest_GA.forest import Forest
from Forest_GA.PIBIC.ga import load_L2R_file, ordernar, Individuo, Consultas
import matplotlib as plt


def main():
    nomeArquivoTrain = "Forest_GA/2003_td_dataset/Fold1/Norm.train.txt"
    nomeArquivoVali = "Forest_GA/2003_td_dataset/Fold1/Norm.vali.txt"
    nomeArquivoTest = "Forest_GA/2003_td_dataset/Fold1/Norm.test.txt"

    '''##############################################################################################################'''
    '''##############################################################################################################'''

    mask = np.ones(64)
    ##print(len(mask))

    print("Lendo Arquivos ...")
    X, y, z = load_L2R_file(nomeArquivoTrain, mask)
    X2, y2, z2 = load_L2R_file(nomeArquivoVali, mask)
    X3, y3, z3 = load_L2R_file(nomeArquivoTest, mask)

    regr = Forest(max_depth=2, random_state=0, n_estimators=1000)

    Forest(bootstrap=True, criterion='mse', max_depth=2,
           max_features='auto', max_leaf_nodes=None,
           min_impurity_decrease=0.0, min_impurity_split=None,
           min_samples_leaf=1, min_samples_split=2,
           min_weight_fraction_leaf=0.0, n_estimators=1000, n_jobs=1,
           oob_score=False, random_state=0, verbose=0, warm_start=False)

    regr.fitLoadTrees(X, y,np.ones(1000), regr.get_Trees())
    score = regr.predict(X2)

    validArrays = Consultas(X2, y2, z2)
    valor_ndgc , map = modelEvaluation(validArrays, score, 64)
    print("NDCG ", np.mean(valor_ndgc))

    comparar = 0
    if comparar == 1:

        trees = regr.get_Trees()
        forest = np.ones(1000)

        ind = Individuo(forest, 1)
        n_queries = 1000


        arquivo = open("predicacao.txt", "w")

        arquivo.write('Resultado Total\n')
        arquivo.write('\n    NDCG@10: ' + str(ind[0].fitness))
        arquivo.write('\n    Arvores: \n\n' + str(forest))

        arquivo.close()


if __name__ == '__main__':
    main()
